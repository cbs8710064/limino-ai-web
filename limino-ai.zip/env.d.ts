/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_APP_APIPATH: string
  readonly VITE_APP_VIDEOPATH: string
}
