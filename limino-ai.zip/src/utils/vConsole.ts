import VConsole from 'vconsole'
const vconsole = new VConsole()
export default vconsole