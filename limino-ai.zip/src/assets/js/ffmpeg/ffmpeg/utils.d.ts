/**
 * Generate an unique message ID.
 */
export declare const getMessageID: () => number;
