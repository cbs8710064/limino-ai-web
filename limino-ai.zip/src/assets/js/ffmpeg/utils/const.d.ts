export declare const HeaderContentLength = "Content-Length";
