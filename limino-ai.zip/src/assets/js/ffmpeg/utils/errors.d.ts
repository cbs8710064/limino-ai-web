export declare const ERROR_RESPONSE_BODY_READER: Error;
export declare const ERROR_INCOMPLETED_DOWNLOAD: Error;
