export type Theme = 'dark' | 'light'
export type LoginType = 'google' | 'discord'
