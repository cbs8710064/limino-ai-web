export const focus = {
  mounted(el: HTMLElement) {
    el.focus()
  }
}
